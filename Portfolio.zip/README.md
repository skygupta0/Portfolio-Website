<h1> Portfolio </h1>
<h2> A portfolio using HTML5, CSS3 & JavaScript!</h2>
What one can see in this project : <br>
- Simplicity <br>
- Modern UI <br>
- Pure CSS <br>
- Easy to understand <br>
- Fully Functional <br>
- Email service for contact/feedback <br>
- Smooth, easy and better UX <br>
- Mobile support (Android as well as IOS)<br>
- Custom navbar for mobile devices (Hamburger menu) <br><br>
For the email service I have used EmailJs as it can send Email Directly From JavaScript and there's no need for a server.<br>
</p>
<h3>🚀 Supports all width sizes including macbooks as well!</h3>
<img src="https://"></br>
<h3>🚀 Mobile device support with various screen widths including iPads which comes with a Hamburger menu on top!</h3>
<i>(View on iPhone11 safari)</i>

<div>
<img src="" width="300rem">&emsp;&emsp;&emsp;
<img src="" width="300rem">
</div>
